"use client"

import type React from "react"

import { useState } from "react"
import { X, Sparkles } from "lucide-react"

interface AddAffirmationModalProps {
  isOpen: boolean
  onClose: () => void
  onSave: (text: string) => void
}

export function AddAffirmationModal({ isOpen, onClose, onSave }: AddAffirmationModalProps) {
  const [text, setText] = useState("")

  const handleSave = () => {
    if (text.trim()) {
      onSave(text.trim())
      setText("")
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && e.ctrlKey) {
      handleSave()
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="w-full max-w-md rounded-2xl bg-card shadow-lg">
        <div className="flex items-center justify-between border-b border-border p-6">
          <div className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            <h2 className="text-xl font-bold text-card-foreground">Add Daily Affirmation</h2>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1 transition-colors hover:bg-muted"
            aria-label="Close modal"
          >
            <X className="h-5 w-5 text-muted-foreground" />
          </button>
        </div>

        <div className="p-6">
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Write your affirmation or positive thought..."
            className="min-h-32 w-full resize-none rounded-lg border border-border bg-background p-4 text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
            autoFocus
          />
          <p className="mt-2 text-xs text-muted-foreground">Ctrl + Enter to save quickly</p>
        </div>

        <div className="flex gap-3 border-t border-border p-6">
          <button
            onClick={onClose}
            className="flex-1 rounded-lg border border-border px-4 py-2.5 font-medium text-foreground transition-colors hover:bg-muted"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={!text.trim()}
            className="flex-1 rounded-lg bg-primary px-4 py-2.5 font-medium text-primary-foreground transition-all hover:shadow-lg disabled:opacity-50"
          >
            Save
          </button>
        </div>
      </div>
    </div>
  )
}
