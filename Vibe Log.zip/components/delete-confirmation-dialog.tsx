"use client"

import { AlertTriangle, X } from "lucide-react"

interface DeleteConfirmationDialogProps {
  onDelete: () => void
  onCancel: () => void
}

export function DeleteConfirmationDialog({ onDelete, onCancel }: DeleteConfirmationDialogProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="w-full max-w-sm rounded-2xl bg-card shadow-lg">
        <div className="flex items-center justify-between border-b border-border p-6">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-destructive" />
            <h2 className="text-lg font-bold text-card-foreground">Delete Affirmation</h2>
          </div>
          <button
            onClick={onCancel}
            className="rounded-lg p-1 transition-colors hover:bg-muted"
            aria-label="Close dialog"
          >
            <X className="h-5 w-5 text-muted-foreground" />
          </button>
        </div>

        <div className="p-6">
          <p className="text-card-foreground">
            Are you sure you want to delete this affirmation? This action cannot be undone.
          </p>
        </div>

        <div className="flex gap-3 border-t border-border p-6">
          <button
            onClick={onCancel}
            className="flex-1 rounded-lg border border-border px-4 py-2.5 font-medium text-foreground transition-colors hover:bg-muted"
          >
            Cancel
          </button>
          <button
            onClick={onDelete}
            className="flex-1 rounded-lg bg-destructive px-4 py-2.5 font-medium text-destructive-foreground transition-all hover:shadow-lg active:scale-95"
          >
            Delete
          </button>
        </div>
      </div>
    </div>
  )
}
