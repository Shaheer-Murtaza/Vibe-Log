"use client"

import type React from "react"

import { useState } from "react"
import { X, Edit3 } from "lucide-react"
import type { Affirmation } from "@/app/page"

interface EditAffirmationModalProps {
  affirmation: Affirmation
  onClose: () => void
  onUpdate: (id: string, text: string) => void
}

export function EditAffirmationModal({ affirmation, onClose, onUpdate }: EditAffirmationModalProps) {
  const [text, setText] = useState(affirmation.text)

  const handleUpdate = () => {
    if (text.trim()) {
      onUpdate(affirmation.id, text.trim())
      onClose()
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && e.ctrlKey) {
      handleUpdate()
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="w-full max-w-md rounded-2xl bg-card shadow-lg">
        <div className="flex items-center justify-between border-b border-border p-6">
          <div className="flex items-center gap-2">
            <Edit3 className="h-5 w-5 text-primary" />
            <h2 className="text-xl font-bold text-card-foreground">Edit Affirmation</h2>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1 transition-colors hover:bg-muted"
            aria-label="Close modal"
          >
            <X className="h-5 w-5 text-muted-foreground" />
          </button>
        </div>

        <div className="p-6">
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={handleKeyDown}
            className="min-h-32 w-full resize-none rounded-lg border border-border bg-background p-4 text-foreground focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
            autoFocus
          />
        </div>

        <div className="flex gap-3 border-t border-border p-6">
          <button
            onClick={onClose}
            className="flex-1 rounded-lg border border-border px-4 py-2.5 font-medium text-foreground transition-colors hover:bg-muted"
          >
            Cancel
          </button>
          <button
            onClick={handleUpdate}
            className="flex-1 rounded-lg bg-primary px-4 py-2.5 font-medium text-primary-foreground transition-all hover:shadow-lg disabled:opacity-50"
            disabled={!text.trim()}
          >
            Update Affirmation
          </button>
        </div>
      </div>
    </div>
  )
}
