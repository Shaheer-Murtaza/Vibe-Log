"use client"

import { Heart } from "lucide-react"

interface HeaderProps {
  onAddClick: () => void
}

export function Header({ onAddClick }: HeaderProps) {
  return (
    <header className="mb-8 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
          <Heart className="h-6 w-6 text-primary-foreground fill-current" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-foreground">Vibe Log</h1>
          <p className="text-sm text-muted-foreground">Daily affirmation tracker</p>
        </div>
      </div>

      <button
        onClick={onAddClick}
        className="flex items-center gap-2 rounded-lg bg-primary px-4 py-2.5 font-medium text-primary-foreground transition-all hover:shadow-lg active:scale-95"
      >
        <span>+</span>
        <span>Add New Affirmation</span>
      </button>
    </header>
  )
}
