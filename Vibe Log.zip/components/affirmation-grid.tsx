"use client"

import { Edit2, Trash2 } from "lucide-react"
import type { Affirmation } from "@/app/page"
import { formatDate } from "@/lib/utils"

interface AffirmationGridProps {
  affirmations: Affirmation[]
  onEdit: (id: string) => void
  onDelete: (id: string) => void
}

export function AffirmationGrid({ affirmations, onEdit, onDelete }: AffirmationGridProps) {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {affirmations.map((affirmation) => (
        <div
          key={affirmation.id}
          className="group relative rounded-2xl bg-card p-6 shadow-sm transition-all hover:shadow-md"
        >
          <p className="mb-4 min-h-24 text-balance text-lg font-medium leading-relaxed text-card-foreground">
            {affirmation.text}
          </p>

          <div className="mb-4 text-xs text-muted-foreground">{formatDate(affirmation.createdAt)}</div>

          <div className="flex gap-2 opacity-0 transition-opacity group-hover:opacity-100">
            <button
              onClick={() => onEdit(affirmation.id)}
              className="flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
              aria-label="Edit affirmation"
            >
              <Edit2 className="h-4 w-4" />
              Edit
            </button>
            <button
              onClick={() => onDelete(affirmation.id)}
              className="flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium text-destructive transition-colors hover:bg-red-50 hover:text-destructive dark:hover:bg-red-950"
              aria-label="Delete affirmation"
            >
              <Trash2 className="h-4 w-4" />
              Delete
            </button>
          </div>
        </div>
      ))}
    </div>
  )
}
