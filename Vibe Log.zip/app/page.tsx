"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { AffirmationGrid } from "@/components/affirmation-grid"
import { AddAffirmationModal } from "@/components/add-affirmation-modal"
import { EditAffirmationModal } from "@/components/edit-affirmation-modal"
import { DeleteConfirmationDialog } from "@/components/delete-confirmation-dialog"

export interface Affirmation {
  id: string
  text: string
  createdAt: Date
}

export default function Home() {
  const [affirmations, setAffirmations] = useState<Affirmation[]>([
    {
      id: "1",
      text: "I am capable of achieving my goals and dreams.",
      createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000),
    },
    {
      id: "2",
      text: "Every day brings new opportunities for growth and positivity.",
      createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000),
    },
    {
      id: "3",
      text: "I choose to focus on what I can control and let go of what I cannot.",
      createdAt: new Date(),
    },
  ])

  const [isAddModalOpen, setIsAddModalOpen] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [deleteId, setDeleteId] = useState<string | null>(null)

  const handleAddAffirmation = (text: string) => {
    const newAffirmation: Affirmation = {
      id: Date.now().toString(),
      text,
      createdAt: new Date(),
    }
    setAffirmations([newAffirmation, ...affirmations])
    setIsAddModalOpen(false)
  }

  const handleUpdateAffirmation = (id: string, text: string) => {
    setAffirmations(affirmations.map((aff) => (aff.id === id ? { ...aff, text } : aff)))
    setEditingId(null)
  }

  const handleDeleteAffirmation = (id: string) => {
    setAffirmations(affirmations.filter((aff) => aff.id !== id))
    setDeleteId(null)
  }

  return (
    <main className="min-h-screen bg-background">
      <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
        <Header onAddClick={() => setIsAddModalOpen(true)} />
        <AffirmationGrid affirmations={affirmations} onEdit={setEditingId} onDelete={setDeleteId} />

        {affirmations.length === 0 && (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="mb-4 text-4xl">✨</div>
            <h2 className="mb-2 text-2xl font-bold text-foreground">No affirmations yet</h2>
            <p className="mb-6 text-muted-foreground">
              Start your vibe! Add your first affirmation to begin your journey.
            </p>
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="rounded-lg bg-primary px-6 py-3 font-medium text-primary-foreground transition-all hover:shadow-lg active:scale-95"
            >
              Add Your First Affirmation
            </button>
          </div>
        )}
      </div>

      <AddAffirmationModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onSave={handleAddAffirmation}
      />

      {editingId && (
        <EditAffirmationModal
          affirmation={affirmations.find((a) => a.id === editingId)!}
          onClose={() => setEditingId(null)}
          onUpdate={handleUpdateAffirmation}
        />
      )}

      {deleteId && (
        <DeleteConfirmationDialog
          onDelete={() => handleDeleteAffirmation(deleteId)}
          onCancel={() => setDeleteId(null)}
        />
      )}
    </main>
  )
}
